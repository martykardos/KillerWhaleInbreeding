#' Retrieve individual genetic loads from genomic data.
#' @param genomeInfo Matrix with the information on the segregating loci
#' @param inGenomes1 First haploid genome copies
#' @param inGenomes2 second haploid genome copies
#' @param multModel Set to TRUE to simulate multiplicative fitness, or to FALSE to simulate additive fitness.
#' @export
getIndivLoads <- function(genomeInfo,inGenomes1,inGenomes2,expRate,fullRecessive,multModel){

  freqMat <- genomeInfo
  genoMat1 <- inGenomes1
  genoMat2 <- inGenomes2

  locusIDs <- colnames(genoMat1)
  delLocusEffs <- as.numeric(freqMat[match(locusIDs,freqMat[,2]),4]) # get the locus effects from freqMat

  #----------------------------------------------
  # calculate the genetic load of each individual
  #----------------------------------------------
  h <- 0.5*(exp(-expRate*as.numeric(delLocusEffs)))           # get the dominance coefficients for deleterious alleles according to Deng & Lynch 1996
  if(fullRecessive == TRUE) h <- rep(0,length(delLocusEffs))
  if(is.null(nrow(genoMat1))){                           # transpose the genotype matrices if needed
    genoMat1 <- t(as.matrix(genoMat1))
    genoMat2 <- t(as.matrix(genoMat2))
  }
  if(is.null(locusIDs) == FALSE & sum(delLocusEffs != 0) > 0){
    if(length(delLocusEffs) == 1) delEffMat <- matrix(rep(as.numeric(delLocusEffs[delLocusEffs != 0]),nrow(genoMat1)),nrow=nrow(genoMat1),ncol=sum(delLocusEffs != 0),byrow=TRUE)   # locus effect matrix
    if(length(delLocusEffs) > 1) delEffMat <- matrix(rep(as.numeric(delLocusEffs[delLocusEffs != 0]),nrow(genoMat1)),nrow=nrow(genoMat1),ncol=sum(delLocusEffs != 0),byrow=TRUE)
    if(length(delLocusEffs) == 1) domEffMat <- matrix(rep(h[delLocusEffs != 0],nrow(genoMat1)),nrow=nrow(genoMat1),ncol=sum(delLocusEffs != 0),byrow=TRUE)    # dominance coefficient matrix
    if(length(delLocusEffs) > 1) domEffMat <- matrix(rep(h[delLocusEffs != 0],nrow(genoMat1)),nrow=nrow(genoMat1),ncol=sum(delLocusEffs != 0),byrow=TRUE)
    derAllCount <- genoMat1 + genoMat2
    hetDelValMat <- (derAllCount == 1) * (domEffMat*delEffMat)    # reduction in fitness due to heterozygous deleterious alleles
    homDelValMat <- (derAllCount == 2) * delEffMat                # reduction in fitness due to homozygous deleterious alleles
    delValMat <- hetDelValMat + homDelValMat                      # all deleterious allele effects

    if(multModel == FALSE)indivLoads <- rowSums(delValMat)      # individual loads under an additive fitness model
    if(multModel == TRUE){                                       # individual loads under a multiplicative model
      theseFits <- rep(1,nrow(delValMat))
      for(y in 1:length(theseFits)){
        if(sum(delValMat[y,] != 0) > 0){
          thisFit <- 1
          theseEffs <- delValMat[y,which(delValMat[y,] != 0)]
          for(my in 1:length(theseEffs)){
            thisFit <- thisFit - (theseEffs[my]*thisFit)
          }
          theseFits[y] <- thisFit
        }
      }
      indivLoads <- 1-theseFits
    }

    if(sum(indivLoads > 1) > 0) indivLoads[indivLoads > 1] <- 1   # fitness cannot be reduced by more than 100%
  }
  indivLoads <<- indivLoads
}
