#' Stochastic simulation of population dynamics and stabilizing selection on a quantitative trait with mutation.
#' @param burnin Number of generations before introducing large-effect mutations. There will only be one large effect allele in the population at any time.
#' @param gens Number of generations to simulate.
#' @param genSize Genome size in bp (linked nucleotides) that affects the quantitative trait
#' @param chroms Number of equal size chromosomes in the genome.
#' @param phen0 The initial mean phenotype.
#' @param phenOpt A vector giving the optimum phentype each generation.
#' @param c Standard deviation (width) of the fitness function.
#' @param mu The quantitative trait mutation rate per base pair.
#' @param quantDom Set to TRUE model dominance variance in the quantitative trait, according to Caballero & Keightley (1994, Genetics). Set to FALSE to model purely additive variants for the quantitative trait.
#' @param quantDomMax Upper limit of the dominance for new mutations with s=0. dominance then declines exponentially with increasing s.
#' @param muOff The last generation of mutation.
#' @param mutationTag Extension for locus names you can use to keep track of where mutation occurred (i.e., in which population).
#' @param minSize The minimum of the uniform distribution of allelic effects (a) on the phenotype.
#' @param maxSize The maximum of the uniform distribution of allelic effects (a) on the phenotype.
#' @param N The initial (and constant before hard selection) population size.
#' @param Ve The desired environmental variance in the phenotype.
#' @param delMutation Set to TRUE if you want deleterious mutation, FALSE if not.
#' @param delMu Deleterious mutation rate per base pair per generation.
#' @param delTargetSize  Number of base pairs subject to deleterioius mutations (i.e., the size of the conserved part of the genome).
#' @param propLethal Proportion of deleterious mutations that are lethal.
#' @param delMuGammaShape gamma distribution shape parameter for deleterious mutation effect sizes on survival.
#' @param delMuGammaScale gamma distribution scale parameter for deleterious mutation effect sizes on survival.
#' @param neutMutation Set to TRUE if you want neutral mutations.
#' @param neutMu Neutral mutation rate per base pair per generation.
#' @param Beta Beta parameter for the rate of decline in dominance with increasing selection coefficient size for deleterious mutations (Deng & Lynch 1996).
#' @param hardSelecGen Generation when you want hard selection and density-dependent population growth to start.
#' @param K Carrying capacity.
#' @param lambda Maximum fitness (i.e., lambda population growth rate at N -> 0).
#' @param f Average (Poisson distributed) number of offspring per mother.
#' @param importGenos Set to FALSE to start with empty genomes. Set to TRUE if you have genotypes to import.
#' @param genoMat1Name Name of the first genotype matrix to import (i.e., the first half of the diploid genome). Set to NULL if you're not importing genotypes.
#'                     Must have genomic data for at least N individuals.
#' @param genoMat2Name Name of the second genotype matrix to import (i.e., the second half of the diploid genome), Set to NULL if you're not importing genotypes.
#'                     Must have genomic data for at least N individuals.
#' @param importGenoIndivs Index the individuals in the genotype matrix that you will use to initialize the new population. Set to NULL if not importing genotypes. Length must equal N.
#' @param genRescue Set to TRUE if you are importing individuals for genetic rescue.
#' @param rescueInGenos1 Name of file containing first genotype copy of genetic rescue individuals.
#' @param rescueInGenos2 Name of file containing second genotype copy of genetic rescue individuals.
#' @param rescueLocusInfo Name of file containing locus information for genetic rescue individuals.
#' @param rescueN Number of individuals you will translocate at each of rescueGens generations into the population for genetic rescue.
#' @param rescueGens Vector of generations when genetic rescue individuals will be translocated into the population.
#' @export
logQuant_mut_delMut_kim<-function(burnin,gens,genSize,chroms,phen0,phenOpt,c,mu,quantDom,quantDomMax,muOff,mutationTag,minSize,maxSize,N,Ve,
         hardSelecGen,K,lambda,f,delMutation,delMu,propLethal,delMuGammaShape,delMuGammaScale,
         neutMutation,neutMu,Beta,importGenos,importGenoIndivs,genoMat1Name,genoMat2Name,locusInfoName,genRescue,rescueInGenos1,
         rescueInGenos2,rescueLocusInfo,rescueN,rescueGens){
  if(length(phenOpt) < gens) stop("phenOpt must have length >= gens")
  if(importGenos == TRUE & is.null(genoMat1Name) == TRUE) stop("Must specify names of genotype files to import")
  if(importGenos == TRUE & is.null(genoMat2Name) == TRUE) stop("Must specify names of genotype files to import")
  if(length(N) < gens)stop("N must have length >= gens")
  fitFun <- function(phen,maxFit,fitPhen,fitSd){maxFit*exp(-(((phen-fitPhen)^2)/(2*fitSd^2)))} # specify the Gaussian fitness function

  ####################################
  # initialize the genotype matrices
  ####################################
  if(importGenos == FALSE){
    genoMat1 <- NULL   # first haploid genome copy
    genoMat2 <- NULL   # second haploid genome copy
    numSeg <- 0 # keep track of the number of segregating loci
  }
  if(importGenos == TRUE){
    genoMat1 <- read.table(genoMat1Name,header=TRUE)   # first haploid genome copy
    colnames(genoMat1) <- unlist(strsplit(colnames(genoMat1),"X"))[seq(2,length(unlist(strsplit(colnames(genoMat1),"X"))),2)]
    genoMat2 <- read.table(genoMat2Name,header=TRUE)   # second haploid genome copy
    colnames(genoMat2) <- unlist(strsplit(colnames(genoMat2),"X"))[seq(2,length(unlist(strsplit(colnames(genoMat2),"X"))),2)]
    if(ncol(genoMat1) < N[1]) stop("Must import genotypes for at least N[1] individuals")
    if(ncol(genoMat2) < N[1]) stop("Must import genotypes for at least N[1] individuals")
    genoMat1 <- genoMat1[importGenoIndivs,]
    genoMat2 <- genoMat2[importGenoIndivs,]
    numSeg <- ncol(genoMat1)# keep track of the number of segregating loci
  }

  #####################################
  # determine chromosome boundaries
  #####################################
  chromStarts <- seq(0,genSize,genSize/chroms)[1:chroms]
  chromEnds <- chromStarts + genSize/chroms

  #######################################
  # initialize objects to store
  # information from the simulation
  #######################################
  segLgEffVec <- rep(NA,gens)
  locusEffs <- NULL
  majorGenos1 <- rep(0,N[1])      # store the genotypes at a major locus (allowing only one at a time) in vectors
  majorGenos2 <- rep(0,N[1])
  genVar <- rep(NA,gens) # track the total genetic variance
  addVar <- rep(NA,gens) # track the additive genetic variance
  addVarFreq <- rep(NA,gens) # track the additive genetic variance
  phenVar <- rep(NA,gens) # track the phenotypic variance
  mutsEst <- (mu+delMu+neutMu)*genSize*2*K[1]*gens   # twice the expected number of mutations throughout the simulation
  if(importGenos == TRUE) mutsEst <- mutsEst + 100000
  if(genRescue == TRUE) mutsEst <- mutsEst + 100000
  Ne <- rep(NA,gens)              # record the effective population size
  if(mutsEst > 100)freqMat <- matrix(NA,nrow=round(mutsEst + 0.5*mutsEst),ncol=6)
  if(mutsEst <= 100)freqMat <- matrix(NA,nrow=100,ncol=6)
  #####################################################
  # enter the locus information if importing genotypes
  #####################################################
  if(importGenos == TRUE){
    locusInfo <- as.matrix(read.table(locusInfoName,header=FALSE))
    freqMat[1:nrow(locusInfo),1:6] <- locusInfo
    freqMat[1:nrow(locusInfo),1] <- 1
  }

  freqList <- list()       # store allele frequencies throughout the simulation
  if(importGenos == FALSE){
    freqList[[1]] <- NA
    locusIDs <- NULL
    locusIter <- 0 # iterate the locus names
    locusEffs <- NULL
    delLocusEffs <- NULL
  }
  if(importGenos == TRUE){
    freqVec <- as.numeric(colSums(rbind(genoMat1,genoMat2))/(2*nrow(genoMat1)))
    freqList[[1]] <- cbind((colnames(genoMat1)),freqVec)
    locusIDs <- colnames(genoMat1)
    locusEffs <- freqMat[match(locusIDs,freqMat[,2]),3]
    delLocusEffs <- freqMat[match(locusIDs,freqMat[,2]),4]
    quantDoms <- freqMat[match(locusIDs,freqMat[,2]),5]           ##############################################*****************
    locusLocs <- freqMat[match(locusIDs,freqMat[,2]),6]
  }


  NVec <- rep(NA,gens)   # keep track of population size through time
  NVec[1] <- N[1]
  extinct <- FALSE    # indicator for extinction
  phenMat <- matrix(NA,nrow=N[1],ncol=gens)
  ######################################################################
  # assign the phenotype for imported individuals if necessary
  ######################################################################
  if(importGenos == FALSE){
    phenMat[,1] <- rnorm(N[1],mean=phen0,sd=sqrt(Ve))
  }
  mutNumVec <- rep(NA,gens)
  numSegVec <- rep(NA,gens)
  piVec <- rep(NA,gens)
  numDelVec <- rep(NA,gens)
  reproMean <- rep(NA,gens)
  reproVar <- rep(NA,gens)
  fitMean<- rep(NA,gens)
  fitVar<- rep(NA,gens)
  parNum <- rep(NA,gens)
  genLoad <- rep(NA,gens)
  lethalEqs <- rep(NA,gens)
  sdLoad <- rep(NA,gens)
  homLoad <- rep(NA,gens)
  if(importGenos == TRUE){
    i <- 1
    if(is.null(locusIDs) == FALSE){
      if(length(locusEffs) == 1) phenEffMat <- matrix(rep(as.numeric(locusEffs),nrow(genoMat1)),nrow=nrow(genoMat1),ncol=ncol(genoMat1),byrow=TRUE)
      if(length(locusEffs) > 1) phenEffMat <- matrix(rep(as.numeric(locusEffs),nrow(genoMat1)),nrow=nrow(genoMat1),ncol=ncol(genoMat1),byrow=TRUE)
      homValMat <- (genoMat1*phenEffMat) + (genoMat2*phenEffMat)   # genetic values for homozygous loci
      homValMat <- homValMat * (genoMat1 == genoMat2) # remove the heterozygous effects
      hetMat <- genoMat1 != genoMat2          # indicator matrix to identify heterozygous individuals

      # make a matrix giving the expected phenotypic effect of heterozygous genotypes
      if(length(locusEffs) == 1) domEffMat <- matrix(rep(as.numeric (quantDoms)*2*as.numeric(locusEffs),nrow(genoMat1)),nrow=nrow(genoMat1),ncol=ncol(genoMat1),byrow=TRUE)
      if(length(locusEffs) > 1) domEffMat <- matrix(rep(as.numeric(quantDoms)*2*as.numeric(locusEffs),nrow(genoMat1)),nrow=nrow(genoMat1),ncol=ncol(genoMat1),byrow=TRUE)

      hetValMat <-  hetMat * domEffMat # proportion of phenotypic effect after accounting for dominance
      genValMat <- homValMat + hetValMat
      genVals <- rowSums(genValMat)
      addVar[i] <- var(genVals)
    }
    if(is.null(locusIDs)){
      genVals <- rep(0,length(dads))
      addVar[i] <- 0
    }

    offPhen <- genVals + rnorm(NVec[i],mean=0,sd=sqrt(Ve))      # assign the phenotypes with genetic and environmental effects
    if(nrow(phenMat) < NVec[i]) phenMat <- rbind(phenMat,matrix(NA,nrow=NVec[i] - nrow(phenMat),ncol=ncol(phenMat)))
    phenMat[1:length(offPhen),i] <- offPhen

    #############################################
    # calculate the genetic variance and h^2
    #############################################
    genVar[i] <- var(genVals)
    phenVar[i] <- var(offPhen)

    ###################################
    # get individual genetic loads
    ###################################

    indivLoads <- rep(NA,N[1])
    h <-  0.5*(1/(1+7071.07*as.numeric(delLocusEffs)))
    if(length(delLocusEffs) == 1) delEffMat <- matrix(rep(delLocusEffs,nrow(genoMat1)),nrow=nrow(genoMat1),ncol=ncol(genoMat1),byrow=TRUE)   # locus effect matrix
    if(length(delLocusEffs) > 1) delEffMat <- matrix(rep(delLocusEffs,nrow(genoMat1)),nrow=nrow(genoMat1),ncol=ncol(genoMat1),byrow=TRUE)
    if(length(delLocusEffs) == 1) domEffMat <- matrix(rep(h,nrow(genoMat1)),nrow=nrow(genoMat1),ncol=ncol(genoMat1),byrow=TRUE)    # dominance coefficient matrix
    if(length(delLocusEffs) > 1) domEffMat <- matrix(rep(h,nrow(genoMat1)),nrow=nrow(genoMat1),ncol=ncol(genoMat1),byrow=TRUE)
    derAllCount <- (genoMat1 + genoMat2)
    hetDelValMat <- (derAllCount == 1) * (domEffMat*delEffMat)    # reduction in fitness due to heterozygous deleterious alleles
    homDelValMat <- (derAllCount == 2) * delEffMat                # reduction in fitness due to homozygous deleterious alleles
    delValMat <- hetDelValMat + homDelValMat                      # all deleterious allele effects
    indivLoads <- rowSums(delValMat)                              # individual loads
    if(sum(is.na(indivLoads)) < length(indivLoads)) if(sum(indivLoads > 1) > 0) indivLoads[indivLoads > 1] <- 1   # fitness cannot be reduced by more than 100%
    genLoad[i] <- mean(indivLoads)
    sdLoad[i] <- sd(indivLoads)
    #calculate lethal equivalents
    lethalEqs[i] <- sum(freqVec*delLocusEffs) - sum(freqVec^2*delLocusEffs)-2*sum(freqVec*(1-freqVec)*delLocusEffs*h)
  }

  ##################################################################
  # initialize a vector of mutation names to use in this simulation
  ##################################################################
  mutNames <- 1:5000000
  i <- 2 # iterate to the second generation

  ##############################################################
  # read in genotypes and locus information for genetic rescue
  # individuals
  ##############################################################
  if(genRescue == TRUE){
    rescueGenos1 <- as.matrix(read.table(rescueInGenos1,header=TRUE))
    rescueGenos2 <- as.matrix(read.table(rescueInGenos2,header=TRUE))

    colnames(rescueGenos1) <- unlist(strsplit(colnames(rescueGenos1),"X"))[seq(2,length(unlist(strsplit(colnames(rescueGenos1),"X"))),2)]
    colnames(rescueGenos2) <- unlist(strsplit(colnames(rescueGenos2),"X"))[seq(2,length(unlist(strsplit(colnames(rescueGenos2),"X"))),2)]

    rescueGenInfo <- as.matrix(read.table(rescueLocusInfo,header=FALSE))
  }
  immigrantIter <- 1               # iterate through immigrants

  while(extinct == FALSE & i <= gens){
    ###################################################################
    # stabilizing selection on the phenotype, inbreeding depression,
    # before the onset of hard selection. This is to allow the genetic
    # variance in the selected phenotype, and the genetic load to
    # accumulate in the population.
    ###################################################################
    if(i < hardSelecGen){
      if(mu != 0)fitness <- fitFun(phen=phenMat[,i-1],maxFit = 1,fitPhen=phenOpt[i],fitSd=c)
      if(mu == 0)fitness <- rep(1,NVec[i-1])
      if(i == 2 & importGenos == FALSE) indivLoads <- rep(0,length(fitness))
      fitness <- fitness - indivLoads*fitness            # penalize fitness with inbreeding depression
      if(sum(fitness < 0,na.rm=TRUE) > 0)fitness[fitness < 0] <- 0
      if(sum(fitness < 0,na.rm=TRUE) == length(fitness)) fitness<-rep(1,length(fitness))
      NVec [i] <- N[i]
    }

    #########################################################
    # survival to breeding after the onset of hard selection
    #########################################################
    if(i >= hardSelecGen){
      if(mu != 0)fitness <- fitFun(phen=phenMat[1:NVec[i-1],i-1],maxFit = lambda,fitPhen=phenOpt[i],fitSd=c) # deterministic total fitness of each individual
      if(mu == 0)fitness <- rep(1,NVec[i-1]) # deterministic total fitness of each individual
      fitness <- fitness - indivLoads*fitness                                       # penalize fitness with inbreeding depression
      if(sum(fitness < 0) > 0)fitness[fitness < 0] <- 0
      expSize <-  NVec[i-1]*exp(log(mean(fitness))*(1-(NVec[i-1]/K)))               # discrete logistic expected size in the next generation
      if(expSize > NVec[i-1] & NVec[i-1] > K) expSize <- K                          # avoid runaway population growth
      meanSurv <- expSize/(NVec[i-1]*f)                                             # mean survival needed to get expSize on average this generation
      nSurvivors <- sum(runif(n=length(fitness),min=0,max=1) < meanSurv)            # number of survivors

      ##########################################
      # test for extinction
      ##########################################
      if(nSurvivors <= 1 | is.null(nSurvivors) | is.na(nSurvivors)){extinct <- TRUE}
      if(extinct == FALSE){
        survivors <- sample(1:length(fitness),nSurvivors,replace=FALSE,prob=fitness/max(fitness))
        NVec[i] <- rpois(1,nSurvivors*f)       # the number of surviving females drive the population dynamics
        momTicker <- 0
        while(momTicker == 0){
          moms <- sample(survivors,size=NVec[i],replace=TRUE)
          if(length(unique(moms)) > 1)momTicker <- 1
        }

        dads <- rep(NA,length(moms))                              # choose dads without allowing selfing
        for(j in 1:length(moms)){
          if(length(survivors[-moms[j]]) > 1) dads[j] <- sample(survivors[-moms[j]],1,replace=FALSE)
          if(length(survivors[-moms[j]]) == 1) dads[j] <- survivors[-moms[j]]
        }
        #-------------------------------------
        # calculate Ne for the last generation
        #-------------------------------------
        uniquePars <- 1:NVec[i-1]
        repro <- rep(NA,length(uniquePars))
        for(j in 1:length(repro)){
          repro [j] <-  sum(c(dads,moms) == uniquePars[j])
        }
        Ne[i-1] <- (4*length(survivors) - 2)/(2  + var(repro))
      }
    }
    fitVar[i] <- var(fitness,na.rm=TRUE)    # save the deterministic fitness variance
    fitMean[i] <- mean(fitness,na.rm=TRUE)

    if(extinct == FALSE){                                        # continue if the population is not extinct
      ########################################################
      # mating
      ########################################################
      if(i < hardSelecGen){
        momTicker <- 0
        while(momTicker == 0){
          moms <- sample(1:NVec[i-1],size=NVec[i],replace=TRUE)
          if(length(unique(moms)) > 1)momTicker <- 1
        }
        if(sum(fitness[1:NVec[i-1]]) > 0)moms <- sample(1:NVec[i-1],size=N[i],replace=TRUE,prob=fitness[1:NVec[i-1]])
        if(sum(fitness[1:NVec[i-1]]) == 0)moms <- sample(1:NVec[i-1],size=N[i],replace=TRUE,prob=rep(1,length(1:NVec[i-1])))
        dads <- rep(NA,length(moms))                              # choose dads without allowing selfing
        for(j in 1:length(moms)){
          if(length((1:NVec[i-1])[-moms[j]]) > 1 & sum(fitness[1:NVec[i-1]][-moms[j]]) > 0)dads[j] <- sample((1:NVec[i-1])[-moms[j]],1,replace=FALSE,prob=fitness[1:NVec[i-1]][-moms[j]])
          if(length((1:NVec[i-1])[-moms[j]]) > 1 & sum(fitness[1:NVec[i-1]][-moms[j]]) == 0)dads[j] <- sample((1:NVec[i-1])[-moms[j]],1,replace=FALSE,prob=rep(1,length(1:length((1:NVec[i-1])[-moms[j]])) ))
          if(length((1:NVec[i-1])[-moms[j]]) == 1)dads[j] <- (1:NVec[i-1])[-moms[j]]

        }
        #-------------------------------------
        # calculate Ne for the last generation
        #-------------------------------------
        uniquePars <- 1:NVec[i-1]
        repro <- rep(NA,length(uniquePars))
        for(j in 1:length(repro)){
          repro [j] <-  sum(c(dads,moms) == uniquePars[j])
        }
        Ne[i-1] <- (4*NVec[i-1] - 2)/(2  + var(repro))
      }
      reproMean[i] <- mean(repro,na.rm=TRUE)
      reproVar[i] <- var(repro,na.rm=TRUE)
      parNum[i] <- length(uniquePars)

      ############################################################
      # meiosis (if there are any segregating loci)
      ############################################################
      if(numSeg > 0){
        ################# identify syntenic loci
        chromIdent <- rep(NA,length(locusIDs))
        for(ve in 1:chroms){
          if(sum(locusLocs > chromStarts[ve] & locusLocs <= chromEnds[ve]) > 0)chromIdent[which(locusLocs > chromStarts[ve] & locusLocs <= chromEnds[ve])] <- ve
        }

        presentChroms <- sort(unique(chromIdent))
        fstGenCopy <- NULL
        secGenCopy <- NULL
        locusCounts <- rep(NA,10)
        for(ri in 1:length(presentChroms)){
          thisChromLoci <- which(locusLocs > chromStarts[presentChroms[ri]] & locusLocs <= chromEnds[presentChroms[ri]])
          locusCounts[ri] <- length(thisChromLoci)
          thisChromLocusLocs <- locusLocs[which(locusLocs > chromStarts[presentChroms[ri]] & locusLocs <= chromEnds[presentChroms[ri]])]
          ################# recombination assuming 50 cM chromosome
          this_fstGenCopy <- matrix(rep(sample(c(TRUE,FALSE),NVec[i],replace=TRUE),length(thisChromLoci)),nrow=NVec[i],ncol=length(thisChromLoci))
          fstRecombs <- sample(c(TRUE,FALSE),size=nrow(this_fstGenCopy),replace=TRUE)            # identify recombinants in the moms
          if(sum(fstRecombs) > 0){
            theseRecombs <- which(fstRecombs == TRUE)
            for(ve in 1:length(theseRecombs)){
              recLoc <- runif(1,1,genSize/chroms) + chromStarts[ri]                     # physical position of this crossover
              thisFirstCopy <- this_fstGenCopy[theseRecombs[ve],1]
              if(thisFirstCopy == FALSE) this_fstGenCopy[theseRecombs[ve],which(thisChromLocusLocs > recLoc)] <- TRUE
              if(thisFirstCopy == TRUE) this_fstGenCopy[theseRecombs[ve],which(thisChromLocusLocs > recLoc)] <- FALSE
            }
          }

          this_secGenCopy <- matrix(rep(sample(c(TRUE,FALSE),NVec[i],replace=TRUE),length(thisChromLoci)),nrow=NVec[i],ncol=length(thisChromLoci))
          fstRecombs <- sample(c(TRUE,FALSE),size=nrow(this_fstGenCopy),replace=TRUE)            # identify recombinants in the moms
          if(sum(fstRecombs) > 0){
            theseRecombs <- which(fstRecombs == TRUE)
            for(ve in 1:length(theseRecombs)){
              recLoc <- runif(1,1,genSize/chroms) + chromStarts[ri]                     # physical position of this crossover
              thisFirstCopy <- this_secGenCopy[theseRecombs[ve],1]
              if(thisFirstCopy == FALSE) this_secGenCopy[theseRecombs[ve],which(thisChromLocusLocs > recLoc)] <- TRUE
              if(thisFirstCopy == TRUE) this_secGenCopy[theseRecombs[ve],which(thisChromLocusLocs > recLoc)] <- FALSE
            }
          }

          fstGenCopy <- cbind(fstGenCopy,this_fstGenCopy)
          secGenCopy <- cbind(secGenCopy,this_secGenCopy)
        }

        # sort the parental genomes
        momsGenos1 <- genoMat1[moms,]
        momsGenos2 <- genoMat2[moms,]
        dadsGenos1 <- genoMat1[dads,]
        dadsGenos2 <- genoMat2[dads,]
        # assign offspring genotypes accounting for recombination and Mendelian segregation
        newGenoMat1 <- (fstGenCopy == TRUE & momsGenos1 == TRUE) | (fstGenCopy == FALSE & momsGenos2 == TRUE)
        newGenoMat2 <- (secGenCopy == TRUE & dadsGenos1 == TRUE) | (secGenCopy == FALSE & dadsGenos2 == TRUE)
        colnames(newGenoMat1) <- colnames(genoMat1)
        colnames(newGenoMat2) <- colnames(genoMat2)
        genoMat1 <- newGenoMat1            #replace the parental genotypes with the offspring genotypes
        genoMat2 <- newGenoMat2
      }

      ##########################################################
      # mutations
      ##########################################################
      ##### first test for the presence of a major locus in the population. Introduce one if there  isn't one already,
      numImmLoci <- 0
      newLocusEffs <- NULL
      newQuantDoms <- NULL
      numMuts <- rbinom(1,genSize*NVec[i]*2,mu)                                                             # number of minor quantitative trait mutations this generation
      mutNumVec [i] <- numMuts

      numQuantMuts <- numMuts            # count the quantitative trait mutations ******
      if (delMutation == TRUE) numDelMuts <- rbinom(1,genSize*NVec[i]*2,delMu) #******
      if (delMutation == FALSE) numDelMuts <- 0 #******
      if(neutMutation == TRUE) numNeutMuts <- rbinom(1,genSize*NVec[i]*2,neutMu)
      if(neutMutation == FALSE) numNeutMuts <- 0
      numMuts <- numQuantMuts + numDelMuts + numNeutMuts #******
      quantMuts <- 1:numQuantMuts #******
      if (delMutation == TRUE & numDelMuts != 0) delMuts <- (numQuantMuts + 1) : (numQuantMuts +  numDelMuts)#******
      if (delMutation == FALSE | numDelMuts == 0) delMuts <- NULL #******
      if (neutMutation == TRUE) neutMuts <- (numQuantMuts + numDelMuts + 1):numMuts #******
      if (neutMutation == FALSE | numNeutMuts == 0) neutMuts <- NULL #******
      if(i >= muOff) numMuts <- 0                                                                           # no mutations if mutation has been shut off
      mutDone <- 0                                                                                          # test for mutation this generation
      if(numMuts > 0) mutInds <- sample(1:NVec[i],size=numMuts,replace=TRUE)                                # determine which offspring the mutation(s) occur in
      if(numMuts > 0 & numSeg == 0){                                                                        # new mutations if there are none already in the population
        locusIter <- which(is.na(freqMat[,1]))[1]#########*********************
        if(importGenos == TRUE) newLocusIDs <- paste(mutNames[1:numMuts],mutationTag,sep="")  # name the new loci
        if(importGenos == FALSE) newLocusIDs <- mutNames[1:numMuts]
        mutNames <- mutNames[-(1:numMuts)]
        mutLocs <- round(runif(numMuts,min=1,max=genSize))       # determine the locations of new mutations on the chromosome
        locusIDs <- newLocusIDs
        locusLocs <- mutLocs                 # save locus locations
        genoMat1 <- matrix(FALSE,nrow=NVec[i],ncol=numMuts)
        genoMat2 <- matrix(FALSE,nrow=NVec[i],ncol=numMuts)
        for(j in 1:ncol(genoMat1)){
          genoMat1[mutInds[j],j] <- TRUE
        }
        colnames(genoMat1) <- locusIDs
        colnames(genoMat2) <- locusIDs
        numSeg <- ncol(genoMat1)
        mutDone <- 1
        if(mu > 0)newLocusEffs <- runif(numSeg,min=minSize,max=maxSize)
        if(mu == 0)newLocusEffs <- rep(0,numSeg)
        if (delMutation == TRUE & numDelMuts != 0) newLocusEffs[delMuts] <- 0 # set the phenotypic effect of deleterious mutations to zero ******
        locusEffs <- newLocusEffs

        # model dominance coefficients for morphological characters mutations according to caballero & keightley (1994, Genetics), if quantDom was set to TRUE
        if(quantDom == TRUE){         #
          newQuantDoms <- rep(NA,length(locusEffs))
          thisPhenSd <- sd(phenMat[,i-1])
          for(ty in 1:length(locusEffs)){
            hLim <- quantDomMax*exp(-1*abs(as.numeric(locusEffs[ty]))/thisPhenSd)
            newQuantDoms[ty] <- runif(1,0,hLim)
          }
        }
        if(quantDom == FALSE) newQuantDoms <- rep(0.5,length(locusEffs))      # assume additive variance only for the quantitative trait
        quantDoms <- newQuantDoms

        newDelLocusEffs <- rep(0,length(newLocusEffs))       # store the deleterious locus effects on survival ***
        if(delMutation == TRUE){
          delLocusSampleEffs <- rgamma(length(delMuts),shape=delMuGammaShape,scale=delMuGammaScale) #****
          lethals <- rbinom(1,length(delLocusSampleEffs),propLethal)#****
          if(lethals > 0)delLocusSampleEffs[sample(1:length(delLocusSampleEffs),lethals,replace=FALSE)] <- 1 #****
          if(sum(delLocusSampleEffs > 1) > 0) delLocusSampleEffs[delLocusSampleEffs>1] <- 1#****
          newDelLocusEffs[delMuts] <- delLocusSampleEffs #****
        }
        if(delMutation == FALSE) delLocusSampleEffs <- NULL
        delLocusEffs <- newDelLocusEffs#****
        numImmLoci <- 0
      }

      if(numMuts > 0 & numSeg > 0 & mutDone == 0){                        # new mutation if there are  already some segregating
        locusIter <- which(is.na(freqMat[,1]))[1]
        if(importGenos == TRUE) newLocusIDs <- paste(mutNames[1:numMuts],mutationTag,sep="")  # name the new loci
        if(importGenos == FALSE) newLocusIDs <- mutNames[1:numMuts]
        mutNames <- mutNames[-(1:numMuts)]

        ############## determine mutation locations
        mutLocs <- rep(NA,numMuts)
        mutLocs <- round(runif(numMuts,min=1,max=genSize))
        checkLocs <- 0
        while(checkLocs == 0){
          if(sum(mutLocs %in% locusLocs) > 0){
            mutLocs[which(mutLocs %in% locusLocs == TRUE)] <- round(runif(sum(mutLocs %in% locusLocs),min=1,max=genSize))
          }
          if(sum(mutLocs %in% locusLocs) == 0)checkLocs <- 1
        }


        if(sum(newLocusIDs %in% freqMat[,2]) > 0)stop(paste("locus names",newLocusIDs[(newLocusIDs %in% freqMat[,2])]," already used"))
        newMat1 <- matrix(FALSE,nrow=NVec[i],ncol=numMuts)      # initialize genotypes at new mutations
        newMat2 <- matrix(FALSE,nrow=NVec[i],ncol=numMuts)
        colnames(newMat1) <- newLocusIDs
        colnames(newMat2) <- newLocusIDs

        for(j in 1:ncol(newMat1)){                              # distribute the mutations among the offspring
          mutPar <- sample(c(1,2),size = 1, replace = FALSE)
          if(mutPar == 1) newMat1[mutInds[j],j] <- TRUE
          if(mutPar == 2) newMat2[mutInds[j],j] <- TRUE
        }
        genoMat1 <- cbind(genoMat1,newMat1)                     # add the new genotypes
        genoMat2 <- cbind(genoMat2,newMat2)
        locusLocs <- c(locusLocs,mutLocs)

        #######################################################
        # import genotypes for immigrants if necessary
        #######################################################
        numImmLoci <- 0       # set new loci brought by immigrants to zero. This will change below if there are any immigrants
        if(i %in% rescueGens == TRUE){


          immGenos1 <- rescueGenos1[1:rescueN,]
          immGenos2 <- rescueGenos2[1:rescueN,]
          immLocusLocs <- rescueGenInfo[,6]
          immLocusEffs <- rescueGenInfo[,3]
          immLocusDelEffs <- rescueGenInfo[,4]
          immLocusDomCoefs <- rescueGenInfo[,5]
          rescueGenos1 <- rescueGenos1[-(1:rescueN),]          # remove the immigrants from the pool of future possible immigrants
          rescueGenos2 <- rescueGenos2[-(1:rescueN),]
          replaceInds <- 1:rescueN     # index the local individuals you will replace immigrant(s)
          genoMat1 <- genoMat1[-replaceInds,]
          genoMat2 <- genoMat2[-replaceInds,]
          newLociMat1 <- NULL
          newLociMat2 <- NULL
          oldLociMat1 <- matrix(FALSE,nrow=length(replaceInds),ncol=ncol(genoMat1))
          oldLociMat2 <- matrix(FALSE,nrow=length(replaceInds),ncol=ncol(genoMat2))
          if(sum(colnames(immGenos1) %in% colnames(genoMat1)) > 0){                      # deal with any loci that are in the immigrants and already present in the focal population
            presentLoci <- colnames(immGenos1)[which(colnames(immGenos1) %in% colnames(genoMat1))]        # which loci are already present in the focal population?
            oldLociMat1[,match(presentLoci,colnames(genoMat1))] <- immGenos1[replaceInds,match(presentLoci,colnames(immGenos1))]
            oldLociMat2[,match(presentLoci,colnames(genoMat2))] <- immGenos2[replaceInds,match(presentLoci,colnames(immGenos2))]
            remPresentLoci <- match(presentLoci,colnames(immGenos1))
            immLocusLocs <- immLocusLocs[-remPresentLoci]
            immLocusEffs <- immLocusEffs[-remPresentLoci]
            immLocusDelEffs <- immLocusDelEffs[-remPresentLoci]
            immLocusDomCoefs <- immLocusDomCoefs[-remPresentLoci]
            immGenos1 <- immGenos1[,-remPresentLoci]       # remove the loci that are already present in the focal population from the immigrant genotype matrices
            immGenos2 <- immGenos2[,-remPresentLoci]

            newLociMat1 <- rbind(immGenos1,matrix(FALSE,nrow=nrow(genoMat1),ncol=ncol(immGenos1)) )    # organize genotypes at new loci brought by the immigrant(s)
            newLociMat2 <- rbind(immGenos2,matrix(FALSE,nrow=nrow(genoMat2),ncol=ncol(immGenos2)) )
            genoMat1 <- rbind(oldLociMat1,genoMat1)
            genoMat2 <- rbind(oldLociMat2,genoMat2)
            genoMat1 <- cbind(genoMat1,newLociMat1)                   # add new loci brought by the immigrant(s)
            genoMat2 <- cbind(genoMat2,newLociMat2)
          }


          if(sum(colnames(immGenos1) %in% colnames(genoMat1)) == 0){      # add the immigrant loci if there are none in the immigrants already present in the receiving population
            newLociMat1 <- rbind(immGenos1,matrix(FALSE,nrow=nrow(genoMat1) - length(replaceInds),ncol=ncol(immGenos1)) )    # organize genotypes at new loci brought by the immigrant(s)
            newLociMat2 <- rbind(immGenos2,matrix(FALSE,nrow=nrow(genoMat2) - length(replaceInds),ncol=ncol(immGenos2)) )
            genoMat1 <- cbind(genoMat1,newLociMat1)                   # add new loci brought by the immigrant(s)
            genoMat2 <- cbind(genoMat2,newLociMat2)
          }
          newLocusIDs <- c(newLocusIDs,colnames(newLociMat1))
          numImmLoci <- length(immLocusLocs)
          locusLocs <- c(locusLocs,immLocusLocs)
        }


        if(mu != 0)newLocusEffs <- runif(numMuts,min=minSize,max=maxSize)           # effect of the new mutations on the phenotype
        if(mu == 0)newLocusEffs <- rep(0,numMuts)           # effect of the new mutations on the phenotype

        locusIDs <- colnames(genoMat1)

        # model dominance coefficients for morphological characters mutations according to caballero & keightley (1994, Genetics), if quantDom was set to TRUE
        if(quantDom == TRUE){         #
          newQuantDoms <- rep(NA,length(newLocusEffs))
          thisPhenSd <- sd(phenMat[,i-1])
          for(ty in 1:length(newLocusEffs)){
            hLim <- exp(-1*abs(as.numeric(newLocusEffs[ty]))/thisPhenSd)
            newQuantDoms[ty] <- runif(1,0,hLim)
          }
        }
        if(quantDom == FALSE) newQuantDoms <- rep(0.5,length(newLocusEffs))      # assume additive variance only for the quantitative trait
        if (delMutation == TRUE){
          newLocusEffs[delMuts] <- 0 # set the phenotypic effect of deleterious mutations to zero ******
          newQuantDoms[delMuts] <- 0.5
        }
        if(neutMutation == TRUE){
          newLocusEffs[neutMuts] <- 0
        }
        quantDoms <- c(quantDoms,newQuantDoms)
        locusEffs <- c(locusEffs,newLocusEffs)
        newDelLocusEffs <- rep(0,length(newLocusEffs))       # store the deleterious locus effects on survival ***
        if(delMutation == TRUE){
          delLocusSampleEffs <- rgamma(length(delMuts),shape=delMuGammaShape,scale=delMuGammaScale) #****
          lethals <- rbinom(1,length(delLocusSampleEffs),propLethal)#****
          if(lethals > 0)delLocusSampleEffs[sample(1:length(delLocusSampleEffs),lethals,replace=FALSE)] <- 1#****
          if(sum(delLocusSampleEffs > 1) > 0) delLocusSampleEffs[delLocusSampleEffs>1] <- 1#****
          newDelLocusEffs[delMuts] <- delLocusSampleEffs #****
        }
        delLocusEffs <- c(delLocusEffs,newDelLocusEffs)#****
        if(i %in% rescueGens == TRUE){
          immDomCoefs <- rescueGenInfo[match(colnames(newLociMat1),rescueGenInfo[,2]),5]#*******************************************     immigrant QTL dominance coefficients
          quantDoms <- c(quantDoms,immDomCoefs)
          locusEffs <- c(locusEffs,immLocusEffs)
          delLocusEffs <- c(delLocusEffs,immLocusDelEffs)
        }
      }

      #####################################################################
      # remove any loci where the derived allele has frequency = 0
      #####################################################################
      allCnts <- NULL
      if(is.null(genoMat1) == FALSE){
        allCnts <- colSums(genoMat1,na.rm=TRUE) + colSums(genoMat2,na.rm=TRUE)
        remLoci <- which(allCnts == 0)
      }
      if(is.null(allCnts) == FALSE & sum(allCnts == 0) > 0){
        genoMat1 <- genoMat1[,-which(allCnts == 0)]
        genoMat2 <- genoMat2[,-which(allCnts == 0)]
        locusIDs <- locusIDs[-which(allCnts == 0)]
        locusEffs <- locusEffs[-which(allCnts == 0)]     #**************
        delLocusEffs <- delLocusEffs[-which(allCnts == 0)] #************
        quantDoms <- quantDoms[-which(allCnts == 0)]  #*******************
        locusLocs <- locusLocs[-which(allCnts == 0)]
        if(sum(allCnts > 0) == 1){
          restartGenoMat1 <- NULL
          restartGenoMat2 <- NULL
          restartGenoMat1 <- cbind(restartGenoMat1,genoMat1)
          restartGenoMat2 <- cbind(restartGenoMat2,genoMat2)
          genoMat1 <- restartGenoMat1
          genoMat2 <- restartGenoMat2
          colnames(genoMat1) <- as.character(locusIDs)
          colnames(genoMat2) <- as.character(locusIDs)
        }
        if(is.null(ncol(genoMat1)) | ncol(genoMat1) == 0){
          outGen1 <- NULL
          outGen2 <- NULL
          outGen1 <- cbind(outGen1,genoMat1)
          outGen2 <- cbind(outGen2,genoMat2)
          genoMat1 <- outGen1
          genoMat2 <- outGen2
          locusIDs <- NULL
        }
      }

      # record the number of segregating mutations
      if(is.null(ncol(genoMat1))) numSeg <- 0
      if(is.null(ncol(genoMat1)) == FALSE){
        if(ncol(genoMat1) == 0) numSeg <- 0
        if(ncol(genoMat1) >= 1) numSeg <- ncol(genoMat1)
      }

      if(numSeg > 1){
        genoMat1 <- genoMat1[,order(as.numeric(locusLocs))]
        genoMat2 <- genoMat2[,order(as.numeric(locusLocs))]
      }

      if(numSeg > 0){
      locusIDs <- locusIDs[order(as.numeric(locusLocs))]
      locusEffs <- locusEffs[order(as.numeric(locusLocs))]     #**************
      delLocusEffs <- delLocusEffs[order(as.numeric(locusLocs))] #************
      quantDoms <- quantDoms[order(as.numeric(locusLocs))] #*******************
      locusLocs <- sort(as.numeric(locusLocs))
      }


      ####################################################
      # save new locus information and allele frequencies
      ####################################################
      if(numMuts + numImmLoci > 0){
        arrivalLoci <- which(locusIDs %in% freqMat[,2] == FALSE) # index arriving loci
        numGenLoci <- sum(locusIDs %in% freqMat[,2] == FALSE)    # number of loci arriving this generation
        genLoci <- rep(i,numGenLoci)      # record the generation when these alleles arose (or arrived by immigration)
        freqDone <- 0                                    # indicator for allele frequency storage
        if(sum(is.na(freqMat[,1])) == nrow(freqMat)){    # in case we have an empty frequency matrix at this point
          outFreqMat <- matrix(c(genLoci,locusIDs[arrivalLoci],locusEffs[arrivalLoci],delLocusEffs[arrivalLoci],quantDoms[arrivalLoci]),ncol=5,nrow=numGenLoci)#*********************************************
          freqMat[1:nrow(outFreqMat),1:5] <- outFreqMat
          freqVec <- as.numeric(colSums(rbind(genoMat1,genoMat2))/(2*NVec[i]))
          freqList[[i]] <- cbind(locusIDs,freqVec)
          freqDone <- 1
          locusIter <- which(is.na(freqMat[,1]))[1]
        }
        if(sum(is.na(freqMat[,1])) < nrow(freqMat) & freqDone == 0 & is.null(genoMat1) == FALSE){    # if there are already loci in the frequency matrix
          outFreqMat <- matrix(c(genLoci,locusIDs[arrivalLoci],locusEffs[arrivalLoci],delLocusEffs[arrivalLoci],quantDoms[arrivalLoci]),ncol=5,nrow=numGenLoci)#*********************************************
          locusIter <- which(is.na(freqMat[,1]))[1]
          freqMat[locusIter:(locusIter + nrow(outFreqMat) - 1),1:5] <- outFreqMat
          locusIter <- which(is.na(freqMat[,1]))[1]
          freqVec <- as.numeric(colSums(rbind(genoMat1,genoMat2))/(2*NVec[i]))
          freqList[[i]] <- cbind((colnames(genoMat1)),freqVec)
        }
      }

      if(is.null(genoMat1) == FALSE){
        if(numMuts + numImmLoci == 0){    # in case there are no new mutations
          if(sum(is.na(freqMat[,1])) != nrow(freqMat) & ncol(genoMat1) >= 1){
            freqVec <- as.numeric(colSums(rbind(genoMat1,genoMat2))/(2*NVec[i]))
            freqList[[i]] <- cbind(colnames(genoMat1),freqVec)
          }
        }
      }

      if(is.null(genoMat1) == FALSE){
        if(ncol(genoMat1)  > 0){
          numSegVec [i] <- ncol(genoMat1)
          numDelVec [i] <- sum(delLocusEffs > 0)
        }
        if(ncol(genoMat1) == 0){
          numSegVec [i] <- 0
          numDelVec [i] <- 0
        }
      }

      if(is.null(genoMat1)){
        numSegVec [i] <- 0
        numDelVec [i] <- 0
      }

      #-------------------------------------
      # get the locus effects from freqMat
      #-------------------------------------
      if(is.null(locusIDs) == FALSE){
        locusEffs <- freqMat[match(locusIDs,freqMat[,2]),3]
        delLocusEffs <- freqMat[match(locusIDs,freqMat[,2]),4]
        quantDoms <- freqMat[match(locusIDs,freqMat[,2]),5]
      }


      ######################################################################
      # assign the offspring phenotype
      ######################################################################

      if(is.null(locusIDs) == FALSE & (sum(locusEffs != 0) > 0)){
        if(length(locusEffs) == 1) phenEffMat <- matrix(rep(as.numeric(locusEffs),nrow(genoMat1)),nrow=nrow(genoMat1),ncol=ncol(genoMat1),byrow=TRUE)
        if(length(locusEffs) > 1) phenEffMat <-  matrix(rep(as.numeric(locusEffs[locusEffs != 0]),nrow(genoMat1)),nrow=nrow(genoMat1),ncol=sum(locusEffs != 0),byrow=TRUE)
        homValMat <- (genoMat1[,locusEffs != 0]*phenEffMat) + (genoMat2[,locusEffs != 0]*phenEffMat)   # genetic values for homozygous loci
        homValMat <- homValMat * (genoMat1[,locusEffs != 0] == genoMat2[,locusEffs != 0]) # remove the heterozygous effects
        hetMat <- genoMat1[,locusEffs != 0] != genoMat2[,locusEffs != 0]          # indicator matrix to identify heterozygous individuals

        # make a matrix giving the expected phenotypic effect of heterozygous genotypes
        if(length(locusEffs) == 1) domEffMat <- matrix(rep(as.numeric (quantDoms[locusEffs != 0])*2*as.numeric(locusEffs[locusEffs != 0]),nrow(genoMat1)),nrow=nrow(genoMat1),ncol=sum(locusEffs != 0),byrow=TRUE)
        if(length(locusEffs) > 1) domEffMat <- matrix(rep(as.numeric(quantDoms[locusEffs != 0])*2*as.numeric(locusEffs[locusEffs != 0]),nrow(genoMat1)),nrow=nrow(genoMat1),ncol=sum(locusEffs != 0),byrow=TRUE)

        hetValMat <-  hetMat * domEffMat # proportion of phenotypic effect after accounting for dominance
        genValMat <- homValMat + hetValMat
        genVals <- rowSums(genValMat)
        addVar[i] <- var(genVals)
      }
      if(is.null(locusIDs) | (sum(locusEffs != 0) == 0)){
        genVals <- rep(0,length(dads))
        addVar[i] <- 0
      }

      if(mu > 0){
        offPhen <- genVals + rnorm(NVec[i],mean=0,sd=sqrt(Ve))      # assign the phenotypes with genetic and environmental effects
        if(nrow(phenMat) < NVec[i]) phenMat <- rbind(phenMat,matrix(NA,nrow=NVec[i] - nrow(phenMat),ncol=ncol(phenMat)))
        phenMat[1:length(offPhen),i] <- offPhen
      }
      if(mu == 0){
        offPhen <- rep(0,NVec[i])
        if(nrow(phenMat) < NVec[i]) phenMat <- rbind(phenMat,matrix(NA,nrow=NVec[i] - nrow(phenMat),ncol=ncol(phenMat)))
        phenMat[1:length(offPhen),i] <- offPhen
      }

      #############################################
      # calculate the genetic variance and h^2
      #############################################
      genVar[i] <- var(genVals)
      phenVar[i] <- var(offPhen)
      print(paste("generation ",i," done*************",sep=""))
      print(paste("genetic variance = ",genVar[i],sep=""))

      ################################################
      # calculate the genetic load of each individual
      ################################################
      # get the dominance coefficients for deleterious alleles according to Deng & Lynch 1996
      h <-  0.5*(1/(1+7071.07*as.numeric(delLocusEffs)))
      if(is.null(locusIDs) == FALSE & sum(delLocusEffs != 0) > 0){
        if(length(delLocusEffs) == 1) delEffMat <- matrix(rep(as.numeric(delLocusEffs[delLocusEffs != 0]),nrow(genoMat1)),nrow=nrow(genoMat1),ncol=sum(delLocusEffs != 0),byrow=TRUE)   # locus effect matrix
        if(length(delLocusEffs) > 1) delEffMat <- matrix(rep(as.numeric(delLocusEffs[delLocusEffs != 0]),nrow(genoMat1)),nrow=nrow(genoMat1),ncol=sum(delLocusEffs != 0),byrow=TRUE)
        if(length(delLocusEffs) == 1) domEffMat <- matrix(rep(h[delLocusEffs != 0],nrow(genoMat1)),nrow=nrow(genoMat1),ncol=sum(delLocusEffs != 0),byrow=TRUE)    # dominance coefficient matrix
        if(length(delLocusEffs) > 1) domEffMat <- matrix(rep(h[delLocusEffs != 0],nrow(genoMat1)),nrow=nrow(genoMat1),ncol=sum(delLocusEffs != 0),byrow=TRUE)
        derAllCount <- (genoMat1[,delLocusEffs != 0] + genoMat2[,delLocusEffs != 0])
        hetDelValMat <- (derAllCount == 1) * (domEffMat*delEffMat)    # reduction in fitness due to heterozygous deleterious alleles
        homDelValMat <- (derAllCount == 2) * delEffMat                # reduction in fitness due to homozygous deleterious alleles
        delValMat <- hetDelValMat + homDelValMat                      # all deleterious allele effects
        indivLoads <- rowSums(delValMat)                              # individual loads
        if(sum(indivLoads > 1) > 0) indivLoads[indivLoads > 1] <- 1   # fitness cannot be reduced by more than 100%
        genLoad[i] <- mean(indivLoads)
        sdLoad[i] <- sd(indivLoads)
        #calculate lethal equivalents
        lethalEqs[i] <- sum(freqVec*as.numeric(delLocusEffs)) - sum(freqVec^2*as.numeric(delLocusEffs))-2*sum(freqVec*(1-freqVec)*as.numeric(delLocusEffs)*h)
        homLoad[i] <- mean(rowSums(homDelValMat))
      }
      if(is.null(locusIDs)){
        genVals <- rep(0,length(dads))
        addVar[i] <- 0
        indivLoads <- rep(0,length(dads))
      }
      if(mu != 0)offPhen <- genVals + rnorm(NVec[i],mean=0,sd=sqrt(Ve))      # assign the phenotypes with genetic and environmental effects
      if(mu == 0)offPhen <- rep(0,NVec[i])      # assign the phenotypes with genetic and environmental effects
      if(nrow(phenMat) < NVec[i]) phenMat <- rbind(phenMat,matrix(NA,nrow=NVec[i] - nrow(phenMat),ncol=ncol(phenMat)))
      phenMat[1:length(offPhen),i] <- offPhen
    }
    print(paste("population size = ",NVec[i],sep=""))
    print(paste("mean phenotype = ",mean(phenMat[,i],na.rm=TRUE)))
    print(paste("mean genetic load = ",mean(indivLoads,na.rm=TRUE)))
    print(paste("lethal equivalents = ",lethalEqs[i],sep=""))
    print(paste("number of polymorphic loci = ", ncol(genoMat1),sep=""))
    if(extinct == TRUE) print(paste("population extinct at generation ",i,sep=""))
    i <- i + 1   # iterate the generation
    if(numSeg > 0) piVec[i] <- sum(2*freqVec*(1-freqVec))/genSize
    if(numSeg == 0) piVec[i] <- 0
    print(paste("pi = ", piVec[i],sep=""))
  }
  # organize allele frequencies
  outFreqs <- matrix(NA,nrow=min(which(is.na(freqMat[,1])))-1,ncol=length(freqList)+1)
  outFreqs[,1] <- freqMat[1:nrow(outFreqs),2]
  outFreqsIndices <- which(is.na(freqList) == FALSE)
  for(i in outFreqsIndices){
    outFreqs[match(freqList[[i]][,1],outFreqs[,1]),i+1] <- freqList[[i]][,2]
  }
  numSegVec <<- numSegVec
  outFreqs[,1] <- 1:nrow(outFreqs)
  outFreqs <<- outFreqs
  genVar   <<- genVar
  phenVar  <<- phenVar
  addVar   <<- addVar
  phenMat  <<- phenMat
  NVec     <<- NVec
  freqMat  <<- freqMat[-which(is.na(freqMat[,1])),]
  Ne <<- Ne
  reproMean <<- reproMean
  reproVar <<- reproVar
  fitMean <<- fitMean
  fitVar <<- fitVar
  parNum <<- parNum
  genoMat1 <<- genoMat1
  genoMat2 <<- genoMat2
  polyInfo <- freqMat[match(colnames(genoMat1),freqMat[,2]),]
  polyInfo[,6] <- locusLocs
  polyInfo <<- polyInfo
  lethalEqs <<- lethalEqs
  piVec <<- piVec
  genLoad <<- genLoad
  sdLoad <<- sdLoad
  homLoad <<- homLoad
}


