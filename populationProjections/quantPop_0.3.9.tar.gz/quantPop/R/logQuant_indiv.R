#' A function for stochastic evolution of a quantitative trait and population dynamics in a population
#'
#' A function for deterministic evolution of a quantitative trait and population dynamics in a population
#' @param N0 Initial population size
#' @param K Carrying capacity
#' @param t Number of generation (non-overlapping) to run
#' @param lambda Fitness of an individual with optimal phenotype in the absence of density dependence
#' @param f Mean fecundity: the mean number of Poisson distributed offspring produced by mothers
#' @param sexType Mating system: "herm" for random mating hermaphrodites, "separate" for random mating separate sexes.
#' @param nLoci Number of loci affecting the quantitative trait (homogeneous effect sizes)
#' @param phen_0 Mean phenotype in generation 1
#' @param phen_opt Optimum phenotype
#' @param fit_sd Standard deviation of the Gaussian fitness function
#' @param h2_0 starting heritability of the quantitative trait
#' @param Vp_0 Starting variance of the selected quantitative trait
#' @param p0 Starting frequency of the allele conferring a larger phenotype
#' @export
logQuantIndiv<- function(N0,K,t,lambda,f,sexType,nLoci,phen_0,phen_opt,fit_sd,h2_0,Vp_0,p0){
  #####################################################
  # track variables through time
  #####################################################
  vpVec <-  rep(NA,t)  # phenotypic variance
  h2Vec <-  rep(NA,t)  # heritability
  freqMat <- matrix(NA,nrow=nLoci,ncol=t+1) # frequency of beneficial the beneficial allele(s)
  NVec <-  rep(NA,t+1)  # population size
  NVec[1] <- N0
  phenVec <- rep(NA,t) # mean phenotype through time
  meanFit <- rep(NA,t) # instantaneous growth rate per-capita

  ##########################
  # initialze the genotypes
  ##########################
  geno1Mat <- matrix(sample(c(0,1),N0*nLoci,replace=TRUE,prob=c(1-p0,p0)),nrow=nLoci,ncol=N0)
  geno2Mat <- matrix(sample(c(0,1),N0*nLoci,replace=TRUE,prob=c(1-p0,p0)),nrow=nLoci,ncol=N0)
  freqMat[,1] <- rowSums(geno1Mat + geno2Mat)/ncol(geno1Mat)
  vQTL <- (h2_0*Vp_0)/nLoci   # genetic variance attributed to each QTL
  a <- sqrt((vQTL/(2*p0*(1-p0))))  # allelic effect
  genVals <- colSums(geno1Mat + geno2Mat)*a     # genetic values in generation 1
  modInt <- phen_0 - mean(genVals) # control the mean phenotype in generation 1
  Ve <- Vp_0 - var(genVals)        # environmental variance

  ###### fitGaus (below) is the gaussian function describing the relationship between phenotype and fitness.
  ###### maxFit is the maximum fitness; fitPhen is the phenotype value with maximum fitness.
  ###### distSd is the sd of the distribution (defines how quickly fitness declines
  ###### from maxFit in either direction from fitPhen). phen is the phenotype value(s) to be evaluated
  fitGaus <- function(phen,maxFit,fitPhen,fitSd){maxFit*exp(-(((phen-fitPhen)^2)/(2*fitSd^2)))}

  ###### fitness function: this is the fitness model (fitGaus) times the phenotype distribution (phenPDF)
  fitFun <- function(phen,phenMu,phenSd,fitPhen,fitSd,maxFit){(1/(phenSd*sqrt(2*pi)))*maxFit*exp(-(((phen-fitPhen)^2)/(2*(fitSd^2)))-(((phen-phenMu)^2)/(2*(phenSd^2))))}

  #################################################
  # simulate the population
  #################################################
  i <- 1
  extinct <- FALSE
  while(i <= t & extinct == FALSE){
    if(nLoci > 1){
      genVals <- colSums(geno1Mat + geno2Mat)*a
      phens <-  modInt + genVals + rnorm(n=ncol(geno1Mat),mean=0,sd=sqrt(Ve))   # individual phenotypes

      #### Get the phenotype mean and variance, and mean fitness this generation
      vpVec [i] <- var(phens)   # total phenotypic variance this generation
      freqs <- (rowSums(geno1Mat) + rowSums(geno2Mat))/(2*nrow(geno1Mat))
      h2Vec [i] <- var(genVals) / vpVec [i] # heritability this generation
      phenVec[i] <- mean(phens)
      fits <- fitGaus(phen=phens,maxFit = lambda,fitPhen=phen_opt,fitSd=fit_sd) # deterministic total fitness of each individual
      expSize <-  NVec[i]*exp(mean(log(fits))*(1-(NVec[i]/K)))   # discrete logistic expected size in the next generation
      meanSurv <- expSize/(NVec[i]*f)   # mean survival needed to get expSize in NVec[i + 1] on average
      nSurvivors <- sum(runif(n=NVec[i],min=0,max=1) < meanSurv)     # number of survivors

      ##########################################
      # test for extinction
      ##########################################
      if(nSurvivors < 2){extinct <- TRUE}
      if(nSurvivors >= 2){
        survivors <- sample(1:NVec[i],nSurvivors,prob=fits/max(fits))   # sample survivors

        ###########################################
        # remove genetic data for non-survivors
        ###########################################
        geno1Mat <- geno1Mat[,survivors]
        geno2Mat <- geno2Mat[,survivors]

        ##########################################
        ##### mating to produce genotypes
        ##########################################
        #pair parents
        if(sexType == "herm"){
          momVec <- 1:ncol(geno1Mat)
          dadVec <- sample(1:ncol(geno1Mat),ncol(geno1Mat),replace=TRUE)
          offNums <- rpois(length(momVec),f)   # number of offspring for each mother
        }

        if(sexType == "separate"){
          momVec <- sample(1:ncol(geno1Mat),round(0.5*ncol(geno1Mat)),replace=FALSE)
          dadVec <- sample((1:ncol(geno1Mat))[-momVec],length(momVec),replace=TRUE)
          offNums <- rpois(length(momVec),f*2)   # number of offspring for each mother
        }
        if(sum(offNums) <2)(extinct <- TRUE)   # declare extinction?
        if(sum(offNums) >= 2){

          ######## make offspring genotypes
          moms <- NULL
          dads <- NULL
          for(j in 1:length(momVec)){
            moms <- c(moms,rep(momVec[j],offNums[j]))
            dads <- c(dads,rep(dadVec[j],offNums[j]))
          }
          moms1 <- geno1Mat[,moms]
          moms2 <- geno2Mat[,moms]
          dads1 <- geno1Mat[,dads]
          dads2 <- geno2Mat[,dads]
          off1 <- matrix(NA,ncol=ncol(moms1),nrow=nrow(moms1))
          off2 <- matrix(NA,ncol=ncol(moms2),nrow=nrow(moms2))
          for (j in 1:nrow(off1)){
            momCopy <- sample(c(1,2),ncol(off1),replace=TRUE)    # randomly sample maternal and paternal alleles
            dadCopy <- sample(c(1,2),ncol(off1),replace=TRUE)
            off1 [j,which(momCopy == 1)] <- moms1[j,which(momCopy == 1)]    # get the maternal gamete
            off1 [j,which(momCopy == 2)] <- moms2[j,which(momCopy == 2)]
            off2 [j,which(dadCopy == 1)] <- dads1[j,which(dadCopy == 1)]    # get the paternal gamete
            off2 [j,which(dadCopy == 2)] <- dads2[j,which(dadCopy == 2)]
          }

          #### advance the genotypes
          geno1Mat <- off1
          geno2Mat <- off2

          #### advance the population to the next generation
          NVec[i + 1] <- ncol(geno1Mat)   # discrete logistic population growth
        }
      }
    }
    i <- i + 1
    #print(i)
 }
 NVec <<- NVec
 freqMat <<- freqMat
 meanFit <<- meanFit
 vpVec <<- vpVec
 h2Vec <<- h2Vec
 phenVec <<- phenVec
 vQTL <<- vQTL
 Ve <<- Ve
 a <<- a
}



