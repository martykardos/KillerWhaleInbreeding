#' Stochastic simulation of population dynamics and stabilizing selection on a quantitative trait with mutation.
#' @param genSize Genome size in bp (linked nucleotides) that affects the quantitative trait
#' @param chroms Number of equal size chromosomes in the genome.
#' @param mothers Mothers of the offspring to simulate
#' @param fathers Fathers of the offspring to simulate
#' @param delMu Deleterious mutation rate per base pair per generation.
#' @param propLethal Proportion of deleterious mutations that are lethal.
#' @param delMuGammaShape gamma distribution shape parameter for deleterious mutation effect sizes on survival.
#' @param delMuGammaScale gamma distribution scale parameter for deleterious mutation effect sizes on survival.
#' @param Beta Beta parameter for the rate of decline in dominance with increasing selection coefficient size for deleterious mutations (Deng & Lynch 1996).
#' @param importGenos Set to FALSE to start with empty genomes. Set to TRUE if you have genotypes to import.
#' @param genoMat1Name Name of the first genotype matrix to import (i.e., the first half of the diploid genome). Set to NULL if you're not importing genotypes.
#'                     Must have genomic data for at least N individuals.
#' @param genoMat2Name Name of the second genotype matrix to import (i.e., the second half of the diploid genome), Set to NULL if you're not importing genotypes.
#'                     Must have genomic data for at least N individuals.
#' @param importGenoIndivs Index the individuals in the genotype matrix that you will use to initialize the new population. Set to NULL if not importing genotypes. Length must equal N.
#' @param inLocusInfo locus information object
#' @export
mating_delMutation<-function(genSize,chroms,mothers, fathers,propLethal,delMu,delMuGammaShape,delMuGammaScale,
                                Beta,importGenos,genoMat1Name,genoMat2Name,genoIDVec,year,inLocusInfo){
  if(importGenos == TRUE & is.null(genoMat1Name) == TRUE) stop("Must specify names of genotype files to import")
  if(importGenos == TRUE & is.null(genoMat2Name) == TRUE) stop("Must specify names of genotype files to import")

  importGenoIndivs=c(which(genosIDs %in% mothers ),which(genosIDs %in% fathers))
  keepGenosIDs <- genoIDVec[importGenoIndivs]
  numImmLoci <- 0 # there are no immigrants allowed
  ####################################
  # initialize the genotype matrices
  ####################################

  if(importGenos == TRUE){
    genoMat1 <- genoMat1Name   # first haploid genome copy
    #colnames(genoMat1) <- unlist(strsplit(colnames(genoMat1),"X"))[seq(2,length(unlist(strsplit(colnames(genoMat1),"X"))),2)]
    genoMat2 <- genoMat2Name   # second haploid genome copy
    #colnames(genoMat2) <- unlist(strsplit(colnames(genoMat2),"X"))[seq(2,length(unlist(strsplit(colnames(genoMat2),"X"))),2)]
    genoMat1 <- genoMat1[importGenoIndivs,]
    genoMat2 <- genoMat2[importGenoIndivs,]
    numSeg <- ncol(genoMat1)# keep track of the number of segregating loci
  }

  #####################################
  # determine chromosome boundaries
  #####################################
  chromStarts <- seq(0,genSize,genSize/chroms)[1:chroms]
  chromEnds <- chromStarts + genSize/chroms

  #######################################
  # initialize objects to store
  # information from the simulation
  #######################################

  mutsEst <- (delMu)*genSize*2*length(mothers)   # twice the expected number of mutations throughout the simulation
  if(importGenos == TRUE) mutsEst <- mutsEst + 10000

  #####################################################
  # enter the locus information if importing genotypes
  #####################################################
  if(importGenos == TRUE){
    locusInfo <- inLocusInfo
    freqMat <- locusInfo
    freqMat[1:nrow(locusInfo),1] <- 0                      # zero indicated these mutation arose from the burnin
    freqMat <- rbind(freqMat,matrix(NA,nrow=1000,ncol=6))
  }

  freqList <- list()       # store allele frequencies throughout the simulation
  if(importGenos == FALSE){
    freqList[[1]] <- NA
    locusIDs <- NULL
    locusIter <- 0 # iterate the locus names

    delLocusEffs <- NULL
  }
  freqList <- list()
  if(importGenos == TRUE){
    freqVec <- as.numeric(colSums(rbind(genoMat1,genoMat2))/(2*nrow(genoMat1)))
    freqList[[1]] <- cbind((colnames(genoMat1)),freqVec)
    locusIDs <- colnames(genoMat1)
    delLocusEffs <- freqMat[match(locusIDs,freqMat[,2]),4]
    locusLocs <- freqMat[match(locusIDs,freqMat[,2]),6]
  }

  ##################################################################
  # initialize a vector of mutation names to use in this simulation
  ##################################################################
  mutNames <- (max(as.numeric(colnames(genoMat1)),na.rm=TRUE)+1):(max(as.numeric(colnames(genoMat1)),na.rm=TRUE)+mutsEst)

  ########################################################
  # mating
  ########################################################
  moms <- match(mothers,keepGenosIDs)   # index the mothers' and fathers' genomes
  dads <- match(fathers,keepGenosIDs)

  ############################################################
  # meiosis (if there are any segregating loci)
  ############################################################
  numSeg <- ncol(genoMat1)

  ################# identify syntenic loci
  chromIdent <- rep(NA,length(locusIDs))
  locusLocs <- as.numeric(locusLocs)
  for(ve in 1:chroms){
    if(sum(locusLocs > chromStarts[ve] & locusLocs <= chromEnds[ve]) > 0) chromIdent[which(locusLocs > chromStarts[ve] & locusLocs <= chromEnds[ve])] <- ve
  }

  presentChroms <- sort(unique(chromIdent))
  fstGenCopy <- NULL
  secGenCopy <- NULL
  locusCounts <- rep(NA,10)
  for(ri in 1:length(presentChroms)){
    thisChromLoci <- which(locusLocs > chromStarts[presentChroms[ri]] & locusLocs <= chromEnds[presentChroms[ri]])
    locusCounts[ri] <- length(thisChromLoci)
    thisChromLocusLocs <- locusLocs[which(locusLocs > chromStarts[presentChroms[ri]] & locusLocs <= chromEnds[presentChroms[ri]])]
    ################# recombination assuming 50 cM chromosomes
    this_fstGenCopy <- matrix(rep(sample(c(TRUE,FALSE),length(mothers),replace=TRUE),length(thisChromLoci)),nrow=length(mothers),ncol=length(thisChromLoci))
    fstRecombs <- sample(c(TRUE,FALSE),size=nrow(this_fstGenCopy),replace=TRUE)            # identify recombinants in the moms
    if(sum(fstRecombs) > 0){
      theseRecombs <- which(fstRecombs == TRUE)
      for(ve in 1:length(theseRecombs)){
        recLoc <- runif(1,1,genSize/chroms) + chromStarts[ri]                     # physical position of this crossover
        thisFirstCopy <- this_fstGenCopy[theseRecombs[ve],1]
        if(thisFirstCopy == FALSE) this_fstGenCopy[theseRecombs[ve],which(thisChromLocusLocs > recLoc)] <- TRUE
        if(thisFirstCopy == TRUE) this_fstGenCopy[theseRecombs[ve],which(thisChromLocusLocs > recLoc)] <- FALSE
      }
    }

    this_secGenCopy <- matrix(rep(sample(c(TRUE,FALSE),length(mothers),replace=TRUE),length(thisChromLoci)),nrow=length(mothers),ncol=length(thisChromLoci))
    fstRecombs <- sample(c(TRUE,FALSE),size=nrow(this_fstGenCopy),replace=TRUE)            # identify recombinants in the moms
    if(sum(fstRecombs) > 0){
      theseRecombs <- which(fstRecombs == TRUE)
      for(ve in 1:length(theseRecombs)){
        recLoc <- runif(1,1,genSize/chroms) + chromStarts[ri]                     # physical position of this crossover
        thisFirstCopy <- this_secGenCopy[theseRecombs[ve],1]
        if(thisFirstCopy == FALSE) this_secGenCopy[theseRecombs[ve],which(thisChromLocusLocs > recLoc)] <- TRUE
        if(thisFirstCopy == TRUE) this_secGenCopy[theseRecombs[ve],which(thisChromLocusLocs > recLoc)] <- FALSE
      }
    }

    fstGenCopy <- cbind(fstGenCopy,this_fstGenCopy)
    secGenCopy <- cbind(secGenCopy,this_secGenCopy)
  }

  # sort the parental genomes
  momsGenos1 <- genoMat1[moms,]
  momsGenos2 <- genoMat2[moms,]
  dadsGenos1 <- genoMat1[dads,]
  dadsGenos2 <- genoMat2[dads,]
  # assign offspring genotypes accounting for recombination and Mendelian segregation
  newGenoMat1 <- (fstGenCopy == TRUE & momsGenos1 == TRUE) | (fstGenCopy == FALSE & momsGenos2 == TRUE)
  newGenoMat2 <- (secGenCopy == TRUE & dadsGenos1 == TRUE) | (secGenCopy == FALSE & dadsGenos2 == TRUE)
  colnames(newGenoMat1) <- colnames(genoMat1)
  colnames(newGenoMat2) <- colnames(genoMat2)
  genoMat1 <- newGenoMat1            #replace the parental genotypes with the offspring genotypes
  genoMat2 <- newGenoMat2


  ##########################################################
  # mutations
  ##########################################################
  numDelMuts <- rbinom(1,genSize*length(mothers)*2,delMu) #******

  numMuts <- numDelMuts

  if (numDelMuts != 0) delMuts <- 1:numDelMuts#******        # index the deleterious mutations
  if (numDelMuts == 0) delMuts <- NULL #******

  mutDone <- 0                                                                                          # test for mutation this generation
  if(numMuts > 0) mutInds <- sample(1:length(moms),size=numMuts,replace=TRUE)                                # determine which offspring the mutation(s) occur in
  if(numMuts > 0 & numSeg == 0){                                                                        # new mutations if there are none already in the population
    locusIter <- which(is.na(freqMat[,1]))[1]
    newLocusIDs <- mutNames[1:numMuts]
    mutNames <- mutNames[-(1:numMuts)]
    mutLocs <- round(runif(numMuts,min=1,max=genSize))       # determine the locations of new mutations on the chromosome
    locusIDs <- newLocusIDs
    locusLocs <- mutLocs                 # save locus locations
    genoMat1 <- matrix(FALSE,nrow=length(mothers),ncol=numMuts)
    genoMat2 <- matrix(FALSE,nrow=length(mothers),ncol=numMuts)
    for(j in 1:ncol(genoMat1)){
      genoMat1[mutInds[j],j] <- TRUE
    }
    colnames(genoMat1) <- locusIDs
    colnames(genoMat2) <- locusIDs
    numSeg <- ncol(genoMat1)
    mutDone <- 1
    newDelLocusEffs <- rep(NA,numDelMuts)       # store the deleterious locus effects on survival ***
    delLocusSampleEffs <- rgamma(length(delMuts),shape=delMuGammaShape,scale=delMuGammaScale) #****
    lethals <- rbinom(1,length(delLocusSampleEffs),propLethal)#****
    if(lethals > 0){
      lethalEffs <- sample(seq(0.95,1,0.01),lethals,replace=TRUE)
      delLocusSampleEffs[sample(1:length(delLocusSampleEffs),lethals,replace=FALSE)] <- lethalEffs#****
    }
    newDelLocusEffs <- delLocusSampleEffs #****
    delLocusEffs <- newDelLocusEffs#****
    numImmLoci <- 0
  }

  if(numMuts > 0 & numSeg > 0 & mutDone == 0){                        # new mutation if there are  already some segregating
    locusIter <- which(is.na(freqMat[,1]))[1]
    #if(importGenos == TRUE) newLocusIDs <- paste(mutNames[1:numMuts],mutationTag,sep="")  # name the new loci
    #if(importGenos == FALSE) newLocusIDs <- mutNames[1:numMuts]
    newLocusIDs <- mutNames[1:numMuts]
    mutNames <- mutNames[-(1:numMuts)]

    ############## determine mutation locations
    mutLocs <- rep(NA,numMuts)
    mutLocs <- round(runif(numMuts,min=1,max=genSize))
    checkLocs <- 0
    while(checkLocs == 0){
      if(sum(mutLocs %in% locusLocs) > 0){
        mutLocs[which(mutLocs %in% locusLocs == TRUE)] <- round(runif(sum(mutLocs %in% locusLocs),min=1,max=genSize))
      }
      if(sum(mutLocs %in% locusLocs) == 0)checkLocs <- 1
    }


    if(sum(newLocusIDs %in% freqMat[,2]) > 0)stop(paste("locus names",newLocusIDs[(newLocusIDs %in% freqMat[,2])]," already used"))
    newMat1 <- matrix(FALSE,nrow=length(moms),ncol=numMuts)      # initialize genotypes at new mutations
    newMat2 <- matrix(FALSE,nrow=length(moms),ncol=numMuts)
    colnames(newMat1) <- newLocusIDs
    colnames(newMat2) <- newLocusIDs

    for(j in 1:ncol(newMat1)){                              # distribute the mutations among the offspring
      mutPar <- sample(c(1,2),size = 1, replace = FALSE)
      if(mutPar == 1) newMat1[mutInds[j],j] <- TRUE
      if(mutPar == 2) newMat2[mutInds[j],j] <- TRUE
    }
    genoMat1 <- cbind(genoMat1,newMat1)                     # add the new genotypes
    genoMat2 <- cbind(genoMat2,newMat2)
    locusLocs <- c(locusLocs,mutLocs)


    locusIDs <- colnames(genoMat1)


    newDelLocusEffs <- NULL       # store the deleterious locus effects on survival ***

      delLocusSampleEffs <- rgamma(length(delMuts),shape=delMuGammaShape,scale=delMuGammaScale) #****
      lethals <- rbinom(1,length(delLocusSampleEffs),propLethal)#****
      if(lethals > 0)delLocusSampleEffs[sample(1:length(delLocusSampleEffs),lethals,replace=FALSE)] <- 1#****
      if(sum(delLocusSampleEffs > 1) > 0) delLocusSampleEffs[delLocusSampleEffs>1] <- 1#****
      newDelLocusEffs <- delLocusSampleEffs #****

    delLocusEffs <- c(delLocusEffs,newDelLocusEffs)#****

  }


  if(is.null(ncol(genoMat1))  | ncol(genoMat1) == 0) numSeg <- 0   # record the number of segregating mutations
  if(ncol(genoMat1) >= 1) numSeg <- ncol(genoMat1)
  if(nrow(genoMat1) > 1){
    genoMat1 <- genoMat1[,order(as.numeric(locusLocs))]
    genoMat2 <- genoMat2[,order(as.numeric(locusLocs))]
  }
  if(nrow(genoMat1) == 1){

    genoVec1 <- genoMat1[1,]
    genoVec2 <- genoMat2[1,]
    locusIDVec <- colnames(genoMat1)
    genoVec1 <- genoVec1[order(as.numeric(locusLocs))]
    genoVec2 <- genoVec2[order(as.numeric(locusLocs))]
    locusIDVec <- locusIDVec[order(as.numeric(locusLocs))]
    genoMat1 <- NULL
    genoMat1 <- NULL
    genoMat1 <- as.matrix(rbind(genoMat1,genoVec1) )
    colnames(genoMat1) <- locusIDVec

    genoMat2 <- NULL
    genoMat2 <- as.matrix(rbind(genoMat2,genoVec2) )
    colnames(genoMat2) <- locusIDVec
  }
  locusIDs <- locusIDs[order(as.numeric(locusLocs))]
  #locusEffs <- locusEffs[order(as.numeric(locusLocs))]
  delLocusEffs <- delLocusEffs[order(as.numeric(locusLocs))]
  #quantDoms <- quantDoms[order(as.numeric(locusLocs))]
  locusLocs <- sort(as.numeric(locusLocs))

  ####################################################
  # save new locus information and allele frequencies
  ####################################################
  if(numMuts + numImmLoci > 0){
    arrivalLoci <- which(locusIDs %in% freqMat[,2] == FALSE) # index newly mutated loci
    numGenLoci <- sum(locusIDs %in% freqMat[,2] == FALSE)    # number of loci arriving via mutation this generation
    genLoci <- rep(year,numGenLoci)      # record the year when these alleles arose (or arrived by immigration)
    freqDone <- 0                                    # indicator for allele frequency storage
    if(sum(is.na(freqMat[,1])) == nrow(freqMat)){    # in case we have an empty frequency matrix at this point
      outFreqMat <- matrix(c(genLoci,locusIDs[arrivalLoci],rep(NA,length(arrivalLoci)),delLocusEffs[arrivalLoci],rep(NA,length(arrivalLoci))),ncol=5,nrow=numGenLoci)#*********************************************
      freqMat[1:nrow(outFreqMat),1:5] <- outFreqMat
      freqVec <- as.numeric(colSums(rbind(genoMat1,genoMat2))/(2*NVec[i]))
      #freqList[[i]] <- cbind(locusIDs,freqVec)
      freqDone <- 1
      locusIter <- which(is.na(freqMat[,1]))[1]
    }
    if(sum(is.na(freqMat[,1])) < nrow(freqMat) & freqDone == 0 & is.null(genoMat1) == FALSE){    # if there are already loci in the frequency matrix
      outFreqMat <- matrix(c(genLoci,locusIDs[arrivalLoci],rep(NA,length(arrivalLoci)),delLocusEffs[arrivalLoci],rep(NA,length(arrivalLoci))),ncol=5,nrow=numGenLoci)#*********************************************
      locusIter <- which(is.na(freqMat[,1]))[1]
      freqMat[locusIter:(locusIter + nrow(outFreqMat) - 1),1:5] <- outFreqMat
      locusIter <- which(is.na(freqMat[,1]))[1]
      freqVec <- as.numeric(colSums(rbind(genoMat1,genoMat2))/(2*length(moms)))
      #freqList[[i]] <- cbind((colnames(genoMat1)),freqVec)
    }
  }
  if(numMuts + numImmLoci == 0){    # in case there are no new mutations
    if(sum(is.na(freqMat[,1])) != nrow(freqMat) & ncol(genoMat1) >= 1){
      freqVec <- as.numeric(colSums(rbind(genoMat1,genoMat2))/(2*length(moms)))
      #freqList[[i]] <- cbind(colnames(genoMat1),freqVec)
    }
  }


  #-------------------------------------
  # get the locus effects from freqMat
  #-------------------------------------
  if(is.null(locusIDs) == FALSE){
    delLocusEffs <- freqMat[match(locusIDs,freqMat[,2]),4]
  }

  # make the output accessible
  freqMat  <<- freqMat[-which(is.na(freqMat[,1])),]
  genoMat1 <<- genoMat1
  genoMat2 <<- genoMat2
  polyInfo <- freqMat[match(colnames(genoMat1),freqMat[,2]),]
  polyInfo[,6] <- locusLocs
  polyInfo <<- polyInfo
}


