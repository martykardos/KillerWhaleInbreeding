#' A function for deterministic evolution of a quantitative trait and population dynamics in a population
#'
#' A function for deterministic evolution of a quantitative trait and population dynamics in a population
#' @param N0 Initial population size
#' @param K Carrying capacity
#' @param t Number of generation (non-overlapping) to run
#' @param lambda Fitness of an individual with optimal phenotype in the absence of density dependence
#' @param nLoci Number of loci affecting the quantitative trait (homogeneous effect sizes)
#' @param phen_0 Mean phenotype in generation 1
#' @param phen_opt Optimum phenotype
#' @param fit_sd Standard deviation of the Gaussian fitness function
#' @param h2_0 starting heritability of the quantitative trait
#' @param Vp_0 Starting variance of the selected quantitative trait
#' @param p0 Starting frequency of the allele conferring a larger phenotype
#' @export

logQuant <- function(N0,K,t,lambda,nLoci,phen_0,phen_opt,fit_sd,h2_0,Vp_0,p0){
  Ve <- Vp_0 - h2_0*Vp_0
  vQTL <- (h2_0*Vp_0)/nLoci   # genetic variance attributed to each QTL
  a <- sqrt((vQTL/(2*p0*(1-p0))))

  ##### calculate the fitness of each genotype
  modInt <- phen_0 - weighted.mean( c(0,a,2*a),c((1-p0)^2,2*p0*(1-p0),(p0)^2))*nLoci # control the mean phenotype in generation 1
  genVals <- c(0,a,2*a) # genetic values for different genotypes
  vpVec <-  rep(NA,t)  # phenotypic variance
  h2Vec <-  rep(NA,t)  # heritability
  freqVec <- rep(NA,t+1) # frequency of beneficial the beneficial allele(s)
  NVec <-  rep(NA,t+1)  # population size
  phenVec <- rep(NA,t) # mean phenotype through time
  meanFit <- rep(NA,t) # instantaneous growth rate per-capita

  ###### fitGaus (below) is the gaussian function describing the relationship between phenotype and fitness.
  ###### maxFit is the maximum fitness; fitPhen is the phenotype value with maximum fitness.
  ###### distSd is the sd of the distribution (defines how quickly fitness declines
  ###### from maxFit in either direction from fitPhen). phen is the phenotype value(s) to be evaluated
  fitGaus <- function(phen,maxFit,fitPhen,fitSd){maxFit*exp(-(((phen-fitPhen)^2)/(2*fitSd^2)))}

  ###### phenPDF (below) is the probability density function for the phenotype in a particular generation.
  ###### phenMu is the mean phenotype
  ###### phenSd is the standard deviation of the phenotype
  ###### phen is the phenotype value(s) to be evaluated
  phenPDF <- function(phen,phenMu,phenSd){(1/(phenSd*sqrt(2*pi)))*exp(-((phen-phenMu)^2)/(2*(phenSd^2)))}

  ###### fitness function: this is the fitness model (fitGaus) times the phenotype distribution (phenPDF)
  fitFun <- function(phen,phenMu,phenSd,fitPhen,fitSd,maxFit){(1/(phenSd*sqrt(2*pi)))*maxFit*exp(-(((phen-fitPhen)^2)/(2*(fitSd^2)))-(((phen-phenMu)^2)/(2*(phenSd^2))))}

  #################################################
  # simulate the population
  #################################################

  for(i in 1:t){
    if(i == 1) {
      NVec[i] <- N0
      freqVec[i] <- p0
    }

    #### Get the phenotype mean and variance, and mean fitness this generation
    genoFreqVec <- c((1-freqVec[i])^2,2*freqVec[i]*(1-freqVec[i]),freqVec[i]^2) # frequencies of genotypes A1A1, A1A2, A2A2
    vpVec [i] <- (genoFreqVec[2]*a^2)*nLoci + Ve   # total phenotypic variance this generation
    h2Vec [i] <- genoFreqVec[2]*a^2*nLoci / vpVec [i] # heritability this generation
    phenVec[i] <- modInt + weighted.mean( genVals,genoFreqVec)*nLoci # mean phenotype this generation
    phenRange <- c(phenVec[i]-4*sqrt(vpVec[i]),phenVec[i]+4*sqrt(vpVec[i]))  # range across which to integreate the fitness function just below here
    meanFit [i] <- integrate(fitFun,lower=phenRange[1],upper=phenRange[2],fitPhen=phen_opt,fitSd=fit_sd,maxFit=lambda,phenMu=phenVec[i],phenSd=sqrt(vpVec[i]))[1][[1]] # mean fitness this generation across all individuals

    #-------------------------------------------------------------------------------------------------
    # mean phenotype for each possible genotype, considering genotype distributions at all other loci
    #-------------------------------------------------------------------------------------------------

    phen_A1A1  <-  modInt + genVals[1] + weighted.mean( genVals,genoFreqVec)*(nLoci-1)  # mean phenotype conditional on being homozygous for the less fit allele at one locus
    phen_A1A2  <-  modInt + genVals[2] + weighted.mean( genVals,genoFreqVec)*(nLoci-1)  # mean phenotype conditional on being heterozygous at one locus
    phen_A2A2  <-  modInt + genVals[3] + weighted.mean( genVals,genoFreqVec)*(nLoci-1)  # mean phenotype conditional on being homozygous for the most fit allele at one locus

    #-------------------------------------------------------------------------------------------------
    # mean fitness for each possible genotype, considering genotype distributions at all other loci
    #-------------------------------------------------------------------------------------------------
    cond_Vp <- (genoFreqVec[2]*a^2)*(nLoci-1) + Ve # phenotypic variance conditional on holding genotype constant at one locus

    # A1A1
    phenRange_A1A1 <- c(phen_A1A1-4*sqrt(cond_Vp),phen_A1A1+4*sqrt(cond_Vp))  # range across which to integreate the fitness function just below here
    meanFit_A1A1 <- integrate(fitFun,lower=phenRange_A1A1[1],upper=phenRange_A1A1[2],fitPhen=phen_opt,fitSd=fit_sd,maxFit=lambda,phenMu=phen_A1A1,phenSd=sqrt(cond_Vp))[1][[1]] # mean fitness for individuals with A1A1 genotypes

    # A1A2
    phenRange_A1A2 <- c(phen_A1A2-4*sqrt(cond_Vp),phen_A1A2+4*sqrt(cond_Vp))  # range across which to integreate the fitness function just below here
    meanFit_A1A2 <- integrate(fitFun,lower=phenRange_A1A2[1],upper=phenRange_A1A2[2],fitPhen=phen_opt,fitSd=fit_sd,maxFit=lambda,phenMu=phen_A1A2,phenSd=sqrt(cond_Vp))[1][[1]] # mean fitness for individuals with A1A2 genotypes

    # A2A2
    phenRange_A2A2 <- c(phen_A2A2-4*sqrt(cond_Vp),phen_A2A2+4*sqrt(cond_Vp))  # range across which to integreate the fitness function just below here
    meanFit_A2A2 <- integrate(fitFun,lower=phenRange_A2A2[1],upper=phenRange_A2A2[2],fitPhen=phen_opt,fitSd=fit_sd,maxFit=lambda,phenMu=phen_A2A2,phenSd=sqrt(cond_Vp))[1][[1]] # mean fitness for individuals with A2A2 genotypes

    #### advance the population to the next generation, while restricting allele frequencies to the range 0:1
    if((freqVec[i]*(1-freqVec[i])*meanFit_A1A2 + (freqVec[i]^2)*meanFit_A2A2)/(meanFit[i]) <= 1) freqVec[i + 1] <- (freqVec[i]*(1-freqVec[i])*meanFit_A1A2 + (freqVec[i]^2)*meanFit_A2A2)/(meanFit[i])
    if((freqVec[i]*(1-freqVec[i])*meanFit_A1A2 + (freqVec[i]^2)*meanFit_A2A2)/(meanFit[i]) > 1) freqVec[i + 1] <- 1
    NVec[i + 1] <- NVec[i]*exp(log(meanFit[i])*(1-(NVec[i]/K)))
  }
  NVec <<- NVec
  freqVec <<- freqVec
  meanFit <<- meanFit
  vpVec <<- vpVec
  h2Vec <<- h2Vec
  phenVec <<- phenVec
  vQTL <<- vQTL
  Ve <<- Ve
  a <<- a
}
